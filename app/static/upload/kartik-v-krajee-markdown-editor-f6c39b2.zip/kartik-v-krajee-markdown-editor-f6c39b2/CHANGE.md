Change Log: `krajee-markdown-editor`
====================================

## version 1.0.0

**Date:** _under development_

- (enh #4): Add Slovak Translations.
- (enh #3): Allow ability to hide/disable specific button actions via `hiddenActions`.
- Initial Release
